<?php

(require __DIR__ . '/../config/bootstrap.php')->run();
